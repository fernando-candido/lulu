import './common/styles/index.css';
import Footer from './components/Footer/Footer';
import Login from './components/Login/Login';

function App() {
  return (
   <>
   <Login/>
   <Footer />
    </>
  );
}

export default App;
